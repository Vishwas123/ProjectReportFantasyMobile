//
//  TeamViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 10/31/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit

class TeamViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    var category = ["Batsman","Bowler","WicketKeeper"]
    
    var hi : Variables!
    
    var team2:Array< String > = Array< String >()
    var key2:Array< String > = Array< String >()
    var value2:Array< String > = Array< String >()
    
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var teamdata = [String : String]()
    var teamDic2 = [String : String]()
    var teamde2:Array< String > = Array< String >()

    var labeltxt = ""
    var teamdata2 = [String : String]()
    var teamdetail2 = [String : String]()
    var player1 = ""
    var player2 = ""
    var player1fin = ""
    var player2fiin = ""
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        key2 = [String](teamdata2.keys)
        value2 = [String](teamdata2.values)
        
        hi = Variables()
        var dat = hi.hello
       // print(dat)
        storeTeamData()
        storeTeamData2()
       print(" from team view2 \(teamdata2)")
        
        

        // Do any additional setup after loading the view.
    }
   override func viewWillAppear(animated: Bool) {
    var teamdata2 = [String : String]()
    teamdata2 = teamdata
    storeTeamData()
    
    print(" from team view1 \(teamdata2)")
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return 11
        
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
       
        var label:UILabel = UILabel()
        label.textColor = UIColor.blueColor()
        label.text = "My Team"
        return label
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        
         labeltxt = cell!.textLabel!.text!
        
        
        
        print("TEXT TEXT \(labeltxt)")
        
        self.performSegueWithIdentifier("PlayerCell", sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "PlayerCell"
        {
            var tab = segue.destinationViewController as! PlayerPoolViewController
            tab.teamda = teamdata
            tab.playername = labeltxt
            
            
        }
    }
    
    
    @IBAction func saveToPlayersViewController(segue:UIStoryboardSegue) {
        
       if let playerView = segue.sourceViewController as? PlayerPoolViewController
       {
          teamDic2 = playerView.teamDictionary12
        
        teamdata = teamDic2
        print("Harsha \(teamdata)")
         teamdetail2 = playerView.playerDic12
        
        teamdata2 = teamdetail2
        
         teamde2 = playerView.team1
        team2 = teamde2
        player1 = playerView.value11
        player1fin = player1
        player2 = playerView.value22
        player2fiin = player2
        viewDidLoad()
        }
        
        
        
        
    }

    @IBAction func cancelToPlayersViewController(segue:UIStoryboardSegue) {
    }

    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
    
        //storeTeamData()
        let cell : UITableViewCell = tableView.dequeueReusableCellWithIdentifier("Teamcell", forIndexPath: indexPath)
        if teamdata.count == 11
        {
            let key = [String](teamdata.keys)
            let value = [String](teamdata.values)
            
            
            cell.textLabel?.text = key[indexPath.row]
            cell.detailTextLabel?.text = value[indexPath.row]
        }
        else
        {
            cell.textLabel?.text = "Select"
            cell.detailTextLabel?.text = "Player Type"
        }
        return cell
    }
    
    
    
    
    func storeTeamData()
    {
        
        
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/Team?email=\(emailid)")!)
        httpGet(request)
        {
                (data, error) -> Void in
                if error != nil
                {
                    print(error)
                }
                else
                {
                    self.extract_json(data)
                }
                
        }
        
        
     /*
        if team2.count == 11
        {
        let logemail = hi.loginemail
        //var a = tea
        var first = "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/playerteam?player1=\(value2[0])&player2=\(value2[1])&player3=\(value2[2])&player4=\(value2[3])&player5=\(value2[4])&"
        var second = "player6=\(value2[5])&player7=\(value2[6])&player8=\(value2[7])&player9=\(value2[8])&player10=\(value2[9])&player11=\(value2[10])&email=\(emailid)"
        let total = "\(first)\(second)"
        
       
            
            //let request = NSMutableURLRequest(URL: NSURL(string: first + second)!)
            var url = NSURL(string: total)!
        
            let request = NSMutableURLRequest(URL: (url))
            

        
        httpGet(request)
        {
                (data, error) -> Void in
                if error != nil {
                    print(error)
                }else {
                    self.extract_json(data)
                }
                
        }
        }
        else
        {
            print("Error...!")
        }
        viewDidLoad()  */
        print(teamdata.count)
        
    }
    
    func storeTeamData2()
    {
        if team2.count == 11
        {
            let logemail = hi.loginemail
            
            print(teamtext)
            //var a = tea
            var first = "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/playerteam?player1=\(value2[0])&player2=\(value2[1])&player3=\(value2[2])&player4=\(value2[3])&player5=\(value2[4])&"
            var second = "player6=\(value2[5])&player7=\(value2[6])&player8=\(value2[7])&player9=\(value2[8])&player10=\(value2[9])&player11=\(value2[10])&email=\(emailid)&teamname=\(teamtext)&league=IndianPremierLeague"
            let total = "\(first)\(second)"
            
            
            
            //let request = NSMutableURLRequest(URL: NSURL(string: first + second)!)
            var url = NSURL(string: total)!
            
            let request = NSMutableURLRequest(URL: (url))
            
            
            
            httpGet(request)
                {
                    (data, error) -> Void in
                    if error != nil {
                        print(error)
                    }else {
                        self.extract_json(data)
                    }
                    
            }
        }
        if team2.count == 1
        {
            let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/oneplayer?player=\(player1fin)&player2=\(player2fiin)&email=\(emailid)")!)
                
                httpGet(request)
                    {
                        (data, error) -> Void in
                        if error != nil {
                            print(error)
                        }else {
                            self.extract_json(data)
                        }
                        
            }

            
            
        }
            
        
        else
        {
            print("Error...!")
        }
       // viewDidLoad()
        
    }
    
    
    
    
    func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
    {
        var result = ""
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil {
                callback("", error!.localizedDescription)
            } else {
                result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)! as String
                callback(result as String, nil)
                //  self.abc = result
            }
        }
        task.resume()
        
    }
    
    func extract_json(data:String)
    {
        
        var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
            let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)
            
            //  print(json)
            if (parseError == nil)
            {
                if let countries_list = json as? NSArray
                {
                    
                    
                    print(countries_list)
                    for (var i = 0; i < countries_list.count ; i++ )
                    {
                        if let country_obj = countries_list[i] as? NSDictionary
                        {
                            //                        print("hello   \(country_obj)")
                            
                            
                            if let country_name = country_obj["PLAYER_NAME"] as? String
                            {
                                
                                // print("hello   \(country_name)")
                                
                                if let country_code = country_obj["PLAYER_TYPE"] as? String
                                {
                                   // let player_id = country_obj["Player_id"] as? Int
                                //    playid.append(player_id!)
                                    
                                    // print(" Hello TEAm \(playid)")
                                    
                                 //   TableData.append(country_name + " [" + country_code + "]")
                                  
                                    
                                    teamdata["\(country_name)"] = "\(country_code)"
                                   
                                    
                                    // playerDic["\(country_name)"] = "\(player_id!)"
                                    
                                  //  print(playerDic)
                                    
                                }
                            }
                        }
                    }
                    
                }
            }
            do_table_refresh();
            
        }
        catch{
            
        }
        
    
    }
    
        func do_table_refresh()
        {
            dispatch_async(dispatch_get_main_queue(), {
                self.tableView.reloadData()
                return
            })
        }

    
   
}
