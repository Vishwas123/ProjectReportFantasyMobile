//
//  RegisterViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 10/29/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {

    
    
    @IBOutlet weak var FirstName: UITextField!
    
    @IBOutlet weak var LastName: UITextField!
    
    @IBOutlet weak var Emailid: UITextField!
    
    
    @IBOutlet weak var pwd: UITextField!
    
    @IBOutlet weak var rpwd: UITextField!
    
    @IBOutlet weak var dob: UITextField!
    
    
    @IBOutlet weak var add: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

    @IBAction func Register(sender: AnyObject)
    {
        let fname = FirstName.text!
        let lname = LastName.text!
        let email = Emailid.text!
        let pwrd = pwd.text!
        let rpwrd = rpwd.text!
        let dateofb = dob.text!
        let addres = add.text!
        var x = ""
        
        if (pwrd != rpwrd)
        {
            displayAlertMessage("Passwords are not same...!")
        }
        if (fname.isEmpty || lname.isEmpty || email.isEmpty || pwrd.isEmpty || rpwrd.isEmpty || dateofb.isEmpty || addres.isEmpty)
        {
            displayAlertMessage("Please fill all the details")
            
        }
        if isValidEmail(email)
        {
        emailid = Emailid.text!
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/registeruser?emailid=\(email)&fname=\(fname)&lname=\(lname)&mname=---&Add1=\(addres)&Add2=---&city=---&state=---&country=---&gender=---&dob=\(dateofb)&usertype=----&zip=---&pword=\(pwrd)&repword=\(rpwrd)&utype=")!)
        httpGet(request){
            (data, error) -> Void in
            if error != nil {
                print(error)
            } else {
                print(data)
                x = data
            }
        }
        if x == "done"
        {
            print(x)
            self.performSegueWithIdentifier("Register", sender: self)
            
        }
        }
        else
        {
            displayAlertMessage("Check error")
        }
        
    }
    func isValidEmail(testStr:String) -> Bool {
        // println("validate calendar: \(testStr)")
        let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(testStr)
    }
    
    
    
    
    
    func displayAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Alert", message:userMessage, preferredStyle: UIAlertControllerStyle.Alert);
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler:nil)
        
        myAlert.addAction(okAction);
        
        self.presentViewController(myAlert, animated: true, completion: nil)
        
    }

    func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
    {
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil {
                callback("", error!.localizedDescription)
            } else {
                let result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)!
                callback(result as String, nil)
            }
        }
        task.resume()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
