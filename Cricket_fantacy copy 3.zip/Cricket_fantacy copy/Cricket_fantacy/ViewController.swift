//
//  ViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 10/29/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit

var emailid = ""
class ViewController: UIViewController
{

    @IBOutlet weak var EmailID: UITextField!
    
    @IBOutlet weak var Passwrd: UITextField!
    
    var em : Variables!
    
    var test = [String]()
    var abc = ""
    override func viewDidLoad()
    {
        super.viewDidLoad()
        em = Variables()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Login(sender: AnyObject)
    {
        var x = EmailID.text!
        let y = Passwrd.text!
         var aaa = ""
        emailid = x
        
        
        if (EmailID.text == "" || Passwrd.text == "")
        {
            let myAlert = UIAlertController(title: "Alert", message:"All fields are required to fill in", preferredStyle: UIAlertControllerStyle.Alert);
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler:nil)
            myAlert.addAction(okAction);
            self.presentViewController(myAlert, animated: true, completion: nil)
            return

        }
    
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/login?email=\(x)&password=\(y)")!)
        httpGet(request){
            (data, error) -> Void in
            if error != nil {
                print(error)
            } else {
                print(data)
                
                aaa = data
                self.test.append(aaa)
            }
        }

        print(abc)
        //print(aaa)
        
        //print("The\(test)")
        if(abc == "Login Successful")
        {
            em.loginemail = EmailID.text!
            print("Hello \(em.loginemail)")
            
            
            self.performSegueWithIdentifier("FromLogin", sender: self)
            
        }
        else if (abc == "Login Failed")
        {
            displayAlertMessage("Please check username and password")
        }
        
        
        
    }
    func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
    {
        var result = ""
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil {
                callback("", error!.localizedDescription)
            } else {
                 result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)! as String
                callback(result as String, nil)
                self.abc = result
                print(result)
            }
        }
        task.resume()
        
    }
    
    @IBAction func cancelToPlayersViewController(segue:UIStoryboardSegue) {
    }
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

    
    func displayAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Alert", message:userMessage, preferredStyle: UIAlertControllerStyle.Alert);
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler:nil)
        
        myAlert.addAction(okAction);
        
        self.presentViewController(myAlert, animated: true, completion: nil)
        
    }
    

   
}

