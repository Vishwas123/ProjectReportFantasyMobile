//
//  SettingsViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 10/31/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//


import UIKit
var type = 0
var typearray = [4,4,2,1]
var teamtext = ""
class SettingsViewController: UIViewController
{

    @IBOutlet weak var team1: UILabel!
    @IBOutlet weak var teamname: UITextField!
    @IBOutlet weak var setting: UISegmentedControl!
    
    @IBOutlet weak var team2: UILabel!
    @IBOutlet weak var team3: UILabel!
    var team = ""
    @IBOutlet weak var team4: UILabel!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        getteamname()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

    @IBOutlet weak var logout: UIButton!

    @IBAction func log(sender: AnyObject)
    {
        displayAlertMessage("Logout Successful. App will be closed...!")
        
        exit(0)
    }
    @IBAction func save(sender: AnyObject)
    {
        teamtext = teamname.text!
    }
    func displayAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Alert", message:userMessage, preferredStyle: UIAlertControllerStyle.Alert);
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler:nil)
        
        myAlert.addAction(okAction);
        
        self.presentViewController(myAlert, animated: true, completion: nil)
        
    }

    @IBAction func settingstype(sender: AnyObject)
    {
        if setting.selectedSegmentIndex == 0
        {
            type = 0
            typearray = [4,4,2,1]
            team1.textColor = UIColor.redColor()
            team2.textColor = UIColor.blackColor()
            team3.textColor = UIColor.blackColor()

            team4.textColor = UIColor.blackColor()

        }
        if setting.selectedSegmentIndex == 1
        {
            typearray = [3,3,4,1]
            type = 1
            team1.textColor = UIColor.blackColor()
            team3.textColor = UIColor.blackColor()
            team4.textColor = UIColor.blackColor()

            team2.textColor = UIColor.redColor()

        }
        if setting.selectedSegmentIndex == 2
        {
            typearray = [4,3,3,1]
            type = 2
            team3.textColor = UIColor.redColor()
            team1.textColor = UIColor.blackColor()
            team2.textColor = UIColor.blackColor()
            team4.textColor = UIColor.blackColor()


        }
        if setting.selectedSegmentIndex == 3
        {
            typearray = [5,1,4,1]
            type = 3
            team1.textColor = UIColor.blackColor()
            team2.textColor = UIColor.blackColor()
            team3.textColor = UIColor.blackColor()

            team4.textColor = UIColor.redColor()

        }
        
        print(typearray)
        print(type)
    }
    
    func getteamname()
    {
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/teamname?email=\(emailid)")!)
        
        httpGet(request)
            {
                (data, error) -> Void in
                if error != nil {
                    print(error)
                }else {
                    self.extract_json(data)
                }
                
        }

    }
    
    func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
    {
        var result = ""
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil {
                callback("", error!.localizedDescription)
            } else {
                result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)! as String
                callback(result as String, nil)
                //  self.abc = result
            }
        }
        task.resume()
        
    }
    
    func extract_json(data:String)
    {
        
        var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
            let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)
            
            //  print(json)
            if (parseError == nil)
            {
                if let countries_list = json as? NSArray
                {
                    
                    
                    print(countries_list)
                    for (var i = 0; i < countries_list.count ; i++ )
                    {
                        if let country_obj = countries_list[i] as? NSDictionary
                        {
                            //                        print("hello   \(country_obj)")
                            
                            
                            if let country_name = country_obj["FANTASY_TEAM_NAME"] as? String
                            {
                                
                                // print("hello   \(country_name)")
                                team = country_name
                                print(team)
                                teamname.text = team

                            }
                        }
                    }
                    
                }
            }
           // do_table_refresh();
            
        }
        catch{
            
        }
        
        
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
