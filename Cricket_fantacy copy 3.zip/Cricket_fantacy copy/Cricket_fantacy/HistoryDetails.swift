//
//  HistoryDetails.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 11/28/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit


class HistoryDetails: UIViewController
{
    
}
