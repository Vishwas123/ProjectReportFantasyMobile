//
//  LeaderboradDetailsViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 11/2/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit

class LeaderboradDetailsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate
{
    @IBOutlet weak var moneySpent: UILabel!

    @IBOutlet weak var moneyLeft: UILabel!
   // @IBOutlet weak var tableView: UITableView!
    
    
    @IBOutlet weak var tableView: UITableView!
    var totalarray = [[String]]()
    var singlearray:Array< String > = Array < String >()

    var id = ""
    var id2 = ""
    override func viewDidLoad()
    {
        
        
        id2 = id
        print("Harsha")
        print("Hello \(id2)")
        
        storeTeamData()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        tableView.reloadData()
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func storeTeamData()
    {
        
        
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/Team?email=\(id)")!)
        httpGet(request)
            {
                (data, error) -> Void in
                if error != nil
                {
                    print(error)
                }
                else
                {
                    self.extract_json(data)
                }
                
        }
    }
    
    func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
    {
        var result = ""
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil {
                callback("", error!.localizedDescription)
            } else {
                result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)! as String
                callback(result as String, nil)
                //  self.abc = result
            }
        }
        task.resume()
        
    }
    
    func extract_json(data:String)
    {
        
        var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
            let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)
            
            //  print(json)
            if (parseError == nil)
            {
                if let countries_list = json as? NSArray
                {
                    
                    
                    print(countries_list)
                    for (var i = 0; i < countries_list.count ; i++ )
                    {
                        if let country_obj = countries_list[i] as? NSDictionary
                        {
                            //                        print("hello   \(country_obj)")
                            
                            
                            if let country_name = country_obj["PLAYER_NAME"] as? String
                            {
                                
                                // print("hello   \(country_name)")
                                
                                if let country_code = country_obj["PLAYER_TYPE"] as? String
                                {
                                   //let teamname = country_obj["TEAM_NAME"] as? String
                                    
                                    singlearray.append(country_name)
                                    singlearray.append(country_code)
                                    //singlearray.append(teamname!)
                                    
                                    totalarray.append(singlearray)
                                    singlearray = []
                                    
                                    
                                    
                                //    teamdata["\(country_name)"] = "\(country_code)"
                                    
                                    
                                }
                            }
                        }
                    }
                    
                }
            }
            do_table_refresh();
            
        }
        catch{
            
        }
        
        
    }
    func do_table_refresh()
    {
        dispatch_async(dispatch_get_main_queue(), {
            self.tableView.reloadData()
            return
        })
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return totalarray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell : UITableViewCell = tableView.dequeueReusableCellWithIdentifier("PlayerCell", forIndexPath: indexPath)
        
        cell.textLabel?.text = "\(totalarray[indexPath.row][0])"
        print("\(cell.textLabel?.text)")
        
        cell.detailTextLabel?.text = "\(totalarray[indexPath.row][1])  "
        
        return cell
    }
    
   override func viewDidAppear(animated: Bool) {
        //print("From detail leader")
    
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
