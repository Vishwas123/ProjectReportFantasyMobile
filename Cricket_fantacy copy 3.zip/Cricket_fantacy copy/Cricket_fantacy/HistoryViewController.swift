//
//  HistoryViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 10/31/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit

class HistoryViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    var TableData:Array< String > = Array < String >()
    var TableData2:Array< String > = Array < String >()
    var totalarray = [[String]]()
    var singlearray:Array< String > = Array < String >()
    var textlable = ""
    var textlable2 = ""
    var textlable3 = ""
    
    @IBOutlet weak var tableView: UITableView!
    var abc = ""

    override func viewDidLoad()
    {
        super.viewDidLoad()
        GetHistory()
        self.tableView.delegate = self
        self.tableView.dataSource = self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
    {
        var result = ""
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil {
                callback("", error!.localizedDescription)
            } else {
                result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)! as String
                callback(result as String, nil)
                self.abc = result
            }
        }
        task.resume()
        
    }
    func do_table_refresh()
    {
        dispatch_async(dispatch_get_main_queue(), {
            self.tableView.reloadData()
            return
        })
    }

    
    func GetHistory()
    {
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/MatchList")!)
        httpGet(request)
            {
                (data, error) -> Void in
                if error != nil {
                    print(error)
                }else {
                    self.extract_json(data)
                }
                
        }
        
    }
    func extract_json(data:String)
    {
        
        
         print("Data   \(data)")
        
        // print("Hello")
        var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
            let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)
            
            //  print(json)
            if (parseError == nil)
            {
                if let countries_list = json as? NSArray
                {
                    //print("hello   \(countries_list)")
                    for (var i = 0; i < countries_list.count ; i++ )
                    {
                        if let country_obj = countries_list[i] as? NSDictionary
                        {
                            // print("hello   \(country_obj)")
                            
                            
                            if let country_name = country_obj["TEAM_ONE"] as? String
                            {
                                
                                // print("hello   \(country_name)")
                                
                                if let country_code = country_obj["TEAM_TWO"] as? String
                                    
                                    
                                {
                                    let country_date = country_obj["MATCHDATE"] as? String
                                    let mtime = country_obj["MATCH_TIME"] as? String
                                    
                                    //let
                                    
                                    let mname = country_name + " Vs " + country_code
                                    let id = country_obj["id"] as? String
                                    
                                    singlearray.append(mname)
                                    singlearray.append(mtime!)
                                    singlearray.append(country_date!)
                                   // singlearray.append(id!)
                                    totalarray.append(singlearray)
                                    
                                    singlearray = []
                                    
                                    
                                    
                                    
                                    TableData.append(country_name + " Vs " + country_code + "")
                                    TableData2.append(country_date!)
                                    
                                }
                                
                            }
                        }
                    }
                }
            }
            
             print(totalarray)
            do_table_refresh();
            
        }
        catch{
            // print("error")
        }
    }
    func get_data_from_url()
    {
        
        
        // print("error")
        let httpMethod = "GET"
        let timeout = 15
        let url = NSURL(string:"http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/MatchList")
        let urlRequest = NSMutableURLRequest(URL: url!)
        let queue = NSOperationQueue()
        NSURLConnection.sendAsynchronousRequest(
            urlRequest,
            queue: queue,completionHandler: {( response: NSURLResponse?, data: NSData?, error: NSError?) -> Void in
                //completionHandler:{ (response: NSURLResponse!, data: NSData!, error: NSError!) -> Void in
                if data!.length > 0 && error == nil{
                    let json = NSString(data: data!, encoding: NSASCIIStringEncoding)
                    self.extract_json(json! as String)
                }else if data!.length == 0 && error == nil{
                    print("Nothing was downloaded")
                } else if error != nil{
                    print("Error happened = \(error)")
                }
            }
        )
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return TableData.count
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        
        var label:UILabel = UILabel()
        label.textColor = UIColor.blueColor()
        label.text = "Matches List"
        return label
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    //    let cell = tableView.
        
        let cell = tableView.cellForRowAtIndexPath(indexPath)!
        if cell.selected
        {
            
            print("Heeee")
            // emid =  totalarray[indexPath.row][4]
            textlable2 = totalarray[indexPath.row][1]
            //   textlable = totalarray[indexPath.row][3]
            var abcd = totalarray[indexPath.row][2]
            var abcd3 = abcd.componentsSeparatedByString("/")
            print(abcd3)
            let abcd2 = abcd3[0] + "-" + abcd3[1] + "-" + abcd3[2]
            textlable3 = abcd2
            print(textlable3)
            
            //  print(emid)
        }
        
        
        if cell.selected
        {
            
            cell.selected = false
            
            
            if cell.accessoryType == UITableViewCellAccessoryType.None
            {
                cell.accessoryType = UITableViewCellAccessoryType.Checkmark
                
                
                
                //cell!
                var abc = cell.textLabel!.text!
                var abc2 = cell.detailTextLabel!.text!
                
                
                textlable2 = totalarray[indexPath.row][1]
                //   textlable = totalarray[indexPath.row][3]
                var abcd = totalarray[indexPath.row][2]
                var abcd3 = abcd.componentsSeparatedByString("/")
                print(abcd3)
                let abcd2 = abcd3[0] + "-" + abcd3[1] + "-" + abcd3[2]
                textlable3 = abcd2
                print(textlable3)
                
                
                //emid = totalarray[indexPath.row][4]
                //emid = abc
                
                cell.accessoryType = UITableViewCellAccessoryType.None
                
            }
                
                
                
            else
            {
                
            }
            
            
        }
        
        self.performSegueWithIdentifier("HistoryDetail", sender: self)
 
        
    }
    
    @IBAction func cancelToPlayersViewController(segue:UIStoryboardSegue) {
    }
 
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("HistoryCell", forIndexPath: indexPath)
        cell.textLabel?.text = totalarray[indexPath.row][0]
        cell.detailTextLabel?.text = totalarray[indexPath.row][2] + totalarray[indexPath.row][1]
        if cell.selected
        {
            
            print("Heeee")
           // emid =  totalarray[indexPath.row][4]
            textlable2 = totalarray[indexPath.row][1]
            //   textlable = totalarray[indexPath.row][3]
            var abcd = totalarray[indexPath.row][2]
            var abcd3 = abcd.componentsSeparatedByString("/")
            print(abcd3)
            let abcd2 = abcd3[0] + "-" + abcd3[1] + "-" + abcd3[2]
            textlable3 = abcd2
            print(textlable3)
            
            //  print(emid)
        }
        
        
        if cell.selected
        {
            
            cell.selected = false
            
            
            if cell.accessoryType == UITableViewCellAccessoryType.None
            {
                cell.accessoryType = UITableViewCellAccessoryType.Checkmark
                
                
                
                //cell!
                var abc = cell.textLabel!.text!
                var abc2 = cell.detailTextLabel!.text!
                
                
                textlable2 = totalarray[indexPath.row][1]
                //   textlable = totalarray[indexPath.row][3]
                var abcd = totalarray[indexPath.row][2]
                var abcd3 = abcd.componentsSeparatedByString("/")
                print(abcd3)
                let abcd2 = abcd3[0] + "-" + abcd3[1] + "-" + abcd3[2]
                textlable3 = abcd2
                print(textlable3)
                
                
                //emid = totalarray[indexPath.row][4]
                //emid = abc
                
                cell.accessoryType = UITableViewCellAccessoryType.None
                
            }
                
                
                
            else
            {
                
            }
            
            
        }

       
        
        
    //    let abcd2 = abcd.stringByReplacingOccurrencesOfString("/", withString: "-")
    //    textlable3 = abcd2
     //   print(textlable2)
        
        return cell
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "HistoryDetail"
        {
            var tab = segue.destinationViewController as! PlayerDetailViewController
            tab.matchdet = totalarray
          //  tab.matchnam = textlable
            tab.matchdat = textlable2
            tab.matchtime = textlable3
            
            
        }
        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
