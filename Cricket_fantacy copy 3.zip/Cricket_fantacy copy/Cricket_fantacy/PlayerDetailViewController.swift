//
//  PlayerDetailViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 11/17/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit

class PlayerDetailViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var TableData1 :[[String]] = [[String]]()
    var singlearray:Array< String > = Array < String >()
    var totalarray = [[String]]()
    var listarray = [[String]]()
    var teamarray:Array< String > = Array < String >()
    var playerarray = [[String]]()
    var matchdet = [[String]]()
    var matchdat = ""
    var matchtime = ""
    var matchnam = ""
     var teamdetails = [String]()
    var email = ""
    @IBOutlet weak var tableView: UITableView!
    var abc = ""
    var date = ""
    var time = ""
    
    
    override func viewDidLoad() {
        
        
      //  print("Harsha  \(matchdat)")
       // print(matchnam)
       // print(matchtime)
        
        GetPointsCri()
        team()
        score()
        
        list()
//        map()
      //  self.tableView.dataSource = self
       // self.tableView.delegate = self
        
       // tableView.reloadData()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func GetPointsCri()
    {
        
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/pointsCri")!)
        httpGet(request){
            (data, error) -> Void in
            if error != nil
            {
                print(error)
            }
            else
            {
                self.extract_json(data)
            }
        }

        
    }
    
    func team()
    {
        print(emailid)
        
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/Team?email=\(emailid)")!)
        httpGet(request)
            {
                (data, error) -> Void in
                if error != nil
                {
                    print(error)
                }
                else
                {
                    self.extract_json3(data)
                }
                
        }
        
        
    }
    
    func score()
    {
        print("HEE HEEE")
        //print("\(matchtime)")
        //print("\(matchdat)")
        print(matchtime)
        print(matchdat)
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/historystats?matchdate=\(matchtime)&time=\(matchdat)")!)
        httpGet(request){
            (data, error) -> Void in
            if error != nil
            {
                print(error)
            }
            else
            {
                print(data)
                self.extract_json2(data)
            }
        }
        
        
    }
    
    
    func extract_json2(data:String)
    {
        
        
        var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
            let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)
            
            print(json)
            if (parseError == nil)
            {
                if let countries_list = json as? NSArray
                {
                    
                    for (var i = 0; i < countries_list.count ; i++ )
                    {
                        if let country_obj = countries_list[i] as? NSDictionary
                        {
                            
                            if let playname = country_obj["PLAYER_NAME"] as? String
                            {
                                
                                
                                let runouts = country_obj["RUNOUTS"] as? Int
                                
                                
                                
                                let runs = country_obj["RUNS"] as? Int
                                let stumps = country_obj["STUMPS"] as? Int
                                let wickets = country_obj["WICKETS"] as? Int
                                let catches = country_obj["CATCHES"] as? Int
                                
                                teamarray.append("\(playname)")
                                teamarray.append("\(runouts!)")
                                teamarray.append("\(runs!)")
                                teamarray.append("\(stumps!)")
                                teamarray.append("\(wickets!)")
                                teamarray.append("\(catches!)")
                                playerarray.append(teamarray)
                                
                                teamarray = []
                                
                            }
                        }
                    }
                    //print(TableData1)
                    // print(TableData)
                    
                }
            }
           // print(singlearray)
            //  print(TableData)
            
           print(playerarray)
           // team()
           // print("Hello")
            
            list()
            //print("Hai")
          //  tableView.reloadData()
            do_table_refresh();
            
        }
        catch{
            // print("error")
        }
    }
    

    
    
    
    func extract_json3(data:String)
    {
        
        
        var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
            let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)

            print(json)
            if (parseError == nil)
            {
                if let countries_list = json as? NSArray
                {
                    
                    for (var i = 0; i < countries_list.count ; i++ )
                    {
                        if let country_obj = countries_list[i] as? NSDictionary
                        {
                            
                            if let country_name = country_obj["PLAYER_NAME"] as? String
                            {
                                teamdetails.append(country_name)
                            }
                        }
                    }
                  //  print(teamdetails)
                    // print(TableData)
                    
                }
            }
            print(teamdetails)
            //  print(TableData)
            do_table_refresh();
            
        }
        catch{
            // print("error")
        }
    }

    
    func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
    {
        var result = ""
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil
            {
                callback("", error!.localizedDescription)
            }
            else
            {
                result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)! as String
                callback(result as String, nil)
                self.abc = result
            }
        }
        task.resume()
        
    }
    
    
    
    
    
    
    func extract_json(data:String)
    {
        
        
        var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
            let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)
            
            print(json)
            if (parseError == nil)
            {
                if let countries_list = json as? NSArray
                {
                   
                    for (var i = 0; i < countries_list.count ; i++ )
                    {
                        if let country_obj = countries_list[i] as? NSDictionary
                        {
                            
                            if let country_name = country_obj["LEAGUE_NAME"] as? String
                            {
                                
                                
                                 let country_code = country_obj["POINTS_FOR_RUN"] as? Int
                                    
                                    
                                
                                    let pointsforwic = country_obj["POINTS_FOR_WICKET"] as? Int
                                    let pointsforcatch = country_obj["POINTS_FOR_CATCH"] as? Int
                                    let pointsforrunout = country_obj["POINTS_FOR_RUNOUT"] as? Int
                                    let pointsforstump = country_obj["POINTS_FOR_STUMP"] as? Int
                                
                                    singlearray.append("\(country_name)")
                                    singlearray.append("\(country_code!)")
                                    singlearray.append("\(pointsforwic!)")
                                    singlearray.append("\(pointsforcatch!)")
                                    singlearray.append("\(pointsforrunout!)")
                                    singlearray.append("\(pointsforstump!)")
                            }
                        }
                    }
                   // print(TableData1)
                   // print(TableData)
                    
                }
            }
            print(singlearray)
            //  print(TableData)
            do_table_refresh();
            
        }
        catch{
            // print("error")
        }
    }
    
    
    func do_table_refresh()
    {
        dispatch_async(dispatch_get_main_queue(), {
            self.tableView.reloadData()
            return
        })
    }
    
    func list()
    {
     //   print("Data")
       // print(teamdetails)
     //   print(playerarray)
        
        print("Sreeharsha Parankusham")
        for var i = 0; i < teamdetails.count; i++
        {
            for var j = 0; j < playerarray.count; j++
            {
                if teamdetails[i] == playerarray[j][0]
                {
                   // var lis = playerarray[j][0]
                    listarray.append(playerarray[j])
                }
            }
        }
        
        print(listarray)
        self.tableView.dataSource = self
        self.tableView.delegate = self
        //viewDidLoad()
        tableView.reloadData()
        
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        
        
        
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
       print("\(listarray.count)")
        
        return listarray.count
    }
    
//func tableView
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("DetailCell", forIndexPath: indexPath)
        var runo = Int(listarray[indexPath.row][1])! * Int(singlearray[4])!
        var run = Int(listarray[indexPath.row][2])! * Int(singlearray[1])!
        var stum = Int(listarray[indexPath.row][3])! * Int(singlearray[5])!
        var wic = Int(listarray[indexPath.row][4])! * Int(singlearray[2])!
        var cat = Int(listarray[indexPath.row][5])! * Int(singlearray[3])!
        var result = runo + run + stum + wic + cat
        
        cell.textLabel?.text = "\(listarray[indexPath.row][0])"
        
        cell.detailTextLabel?.text = "\(result)"
        
        //cell.textLabel?.text = listarray[indexPath.row][0]
        
       // cell.detailTextLabel?.text = "\(result)"
        
        
        return cell
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
