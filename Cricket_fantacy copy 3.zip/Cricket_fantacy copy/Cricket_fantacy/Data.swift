//
//  Data.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 11/22/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import Foundation

class Variables
{
    
    var hello = "Hello"
    var loginemail = ""
    var teamname = ""
    
    
}

