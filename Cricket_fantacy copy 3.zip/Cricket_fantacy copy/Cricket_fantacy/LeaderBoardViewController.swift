//
//  LeaderBoardViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 10/31/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit

class LeaderBoardViewController: UIViewController, UITableViewDataSource,UITableViewDelegate
{

    //@IBOutlet weak var tableview: UITableView!
    
    var textlable = ""
    @IBOutlet weak var tableView: UITableView!
    var TableData:Array< String > = Array < String >()
    var TableData3:Array< String > = Array < String >()
    var TableData1 :[[String]] = [[String]]()
    var singlearray:Array< String > = Array < String >()
    var sing = [String]()
    var totalarray = [[String]]()

    
    var emid = ""
    var abc = ""
    override func viewDidLoad()
    {
        super.viewDidLoad()

        GetLeaderData()
       // totalarray = [[]]
       // GetLeaderData()
        
        //self.tableView.dataSource = self
       // self.tableView.delegate = self
        
        
    }
    
    override func viewDidAppear(animated: Bool) {

        
        GetLeaderData()

    
        tableView.reloadData()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
    }
    
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return totalarray.count
    }
    
    
    
    
    
    
     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("LeaderCell", forIndexPath: indexPath)
       
        if totalarray[indexPath.row][4] == emailid
        {
            cell.textLabel?.textColor = UIColor.redColor()
            cell.detailTextLabel?.textColor = UIColor.redColor()
            cell.textLabel?.text = "\(indexPath.row + 1). " + totalarray[indexPath.row][0]
            cell.detailTextLabel?.text = " \(totalarray[indexPath.row][2]) ;  \(totalarray[indexPath.row][3])"
            
        }
        
        else
        {
            cell.textLabel?.text = "\(indexPath.row + 1). " + totalarray[indexPath.row][0]
            cell.detailTextLabel?.text = " \(totalarray[indexPath.row][2]) ;  \(totalarray[indexPath.row][3])"
        }
        
        
        if cell.selected
        {
            emid =  totalarray[indexPath.row][4]
            //  print(emid)
        }
        
        
        if cell.selected
        {
            
            cell.selected = false
            
            
            if cell.accessoryType == UITableViewCellAccessoryType.None
            {
                    cell.accessoryType = UITableViewCellAccessoryType.Checkmark
                    
                    
                    
                    //cell!
                    var abc = cell.textLabel!.text!
                    var abc2 = cell.detailTextLabel!.text!
                
                
                emid = totalarray[indexPath.row][4]
                //emid = abc
                
                cell.accessoryType = UITableViewCellAccessoryType.None
                
            }
                
            
                
            else
            {
                
            }
            
            
        }

        return cell
    }
    
    @IBAction func cancel(sender: AnyObject)
    {
        
    }
    @IBAction func cancelToPlayersViewController(segue:UIStoryboardSegue) {
    }

    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        
        print("Selected cell \(indexPath.row)!")
        
        let indexPath = tableView.indexPathForSelectedRow
        let cell3 = tableView.cellForRowAtIndexPath(indexPath!)
        textlable =  totalarray[indexPath!.row][4]
        // print("\(textlable)")
        
        self.performSegueWithIdentifier("LeaderCell", sender: self)
        
        
        
    }
    
    
    
    func extract_json(data:String)
    {
        
        
            var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
        let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)
        
           print(json)
        if (parseError == nil)
        {
            if let countries_list = json as? NSArray
            {
                              //print("hello   \(countries_list)")
                for (var i = 0; i < countries_list.count ; i++ )
                {
                    if let country_obj = countries_list[i] as? NSDictionary
                    {
                     // print("hello   \(country_obj)")
                        
                        
                        if let country_name = country_obj["FIRST_NAME"] as? String
                        {
                            
                           // print("hello   \(country_name)")
                            
                            if let country_code = country_obj["EMAIL"] as? String
                                
                                
                            {
                                let teamname = country_obj["FANTASY_TEAM_NAME"] as? String
                                let points = country_obj["TOTAL_POINTS"] as? Int
                                let emailid1 = country_obj["EMAIL"] as? String
                                let pointsstring = "\(points!)"
                                
                                singlearray.append(country_name)
                                singlearray.append(country_code)
                                singlearray.append(teamname!)
                                singlearray.append(pointsstring)
                                singlearray.append(emailid1!)
                                if sing.contains(emailid1!)
                                {
                                    
                                }
                                else
                                {
                                    sing.append(emailid1!)
                                    totalarray.append(singlearray)
                                }
                                singlearray = []
                                
                                TableData.append(country_name )
                                TableData3.append(country_code)
                                
                            }
                                
                        }
                    }
                }
                print(TableData1)
                print(TableData)

            }
        }
            
      //  print(TableData)
        do_table_refresh();
        
        }
        catch{
           // print("error")
        }
    }
    
    
    func do_table_refresh()
    {
        dispatch_async(dispatch_get_main_queue(), {
            self.tableView.reloadData()
            return
        })
    }


    @IBAction func GetLeaderBoard(sender: AnyObject)
    {
        
      //  var json : NSData
        
        
       // get_data_from_url()
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/LeaderBoard")!)
        httpGet(request){
            (data, error) -> Void in
            if error != nil
            {
                print(error)
            }
            else
            {
                self.extract_json(data)
            }
        }

      //  print(abc)

    }
    
    func GetLeaderData()
    {
      //  get_data_from_url()
        //totalarray = [[]]
        
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/LeaderBoard")!)
        httpGet(request){
            (data, error) -> Void in
            if error != nil
            {
                print(error)
            }
            else
            {
                self.extract_json(data)
            }
        }

    }
    
    
    
    
    
   func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
   {
        var result = ""
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil
            {
                callback("", error!.localizedDescription)
            }
            else
            {
                result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)! as String
                callback(result as String, nil)
                self.abc = result
            }
        }
        task.resume()
        
    }
    
    
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "LeaderCell"
        {
            var leader = segue.destinationViewController as! LeaderboradDetailsViewController
         //   let tab = leader.topViewController as! LeaderboradDetailsViewController
            
           // var tab = segue.destinationViewController as! LeaderboradDetailsViewController
         //   print(textlable)
            
            leader.id = textlable
         //   print(tab.id)
        }
        
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
