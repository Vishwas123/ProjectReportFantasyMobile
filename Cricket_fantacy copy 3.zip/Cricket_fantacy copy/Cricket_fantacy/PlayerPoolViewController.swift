//
//  PlayerPoolViewController.swift
//  Cricket_fantacy
//
//  Created by Sreeharsha Parankusham on 11/3/15.
//  Copyright © 2015 Sreeharsha Parankusham. All rights reserved.
//

import UIKit

class PlayerPoolViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    var pri = 50000
    
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var TableData:Array< String > = Array < String >()
    var team:Array< String > = Array< String >()
    var team1:Array< String > = Array< String >()
    var teambow:Array< String > = Array< String >()
    var teambat:Array< String > = Array< String >()
    var teamwik:Array< String > = Array< String >()
    var teamall:Array< String > = Array< String >()
     var teamDictionary12 = [String : String]()
    var indexdata = [Int]()
    var teamda = [String : String]()
    var playid:Array< Int > = Array< Int >()
    var teamDictionary = [String : String]()
    var teamDictionary2 = [String : String]()
    var teamDictionary3 = [String : String]()
    var Bowler = [String : String]()
    var Batsman = [String : String]()
    var WicketKeepr = [String : String]()
    var AllROunder = [String : String]()
    var totalarray = [[String]]()
    var totalarrayBowler = [[String]]()
    var totalarrayBatsman = [[String]]()
    var totalarrayAllRounder = [[String]]()
    var totalarrayWicketKeeper = [[String]]()
    var singlearray:Array< String > = Array < String >()
    var playerDic = [String : String]()
    var playerDic2 = [String : String]()
    var playerDic12 = [String : String]()
    var keys = [String]()
    var playername = ""
    var value = ""
    var value2 = ""
    
    var value11 = ""
    var value22 = ""
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        GetPlayerPool()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        tableView.reloadData()
      let keys1 = [String](teamda.keys)
        keys = keys1
        print(playername)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var Save: UIBarButtonItem!

    @IBAction func TeamSave(sender: AnyObject)
    {
        if teamDictionary2.count == 11 || playername != "Select"
        {
            //displayAlertMessage("You have selected you team")
            
            self.performSegueWithIdentifier("SaveCell", sender: self)
           // self.dismissViewControllerAnimated(false, completion: nil)
        }
        else
        {
            displayAlertMessage("Please select 11 players.")
        }
    }
    @IBAction func Save(sender: AnyObject)
    {
        if teamDictionary2.count == 11 || playername != "Select"
        {
            //displayAlertMessage("You have selected you team")
            
            self.performSegueWithIdentifier("SaveCell", sender: self)
           // self.dismissViewControllerAnimated(false, completion: nil)
            
        }
        else
        {
            displayAlertMessage("Please select 11 players.")
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if segue.identifier == "SaveCell"
        {
            
            teamDictionary12 = teamDictionary2
            
             playerDic12 = playerDic2
            
             team1 = team
            
                value11 = value
                value22 = value2
            
            
           
            
            
        }
    }
    @IBAction func TeamCancel(sender: AnyObject)
    {
        
    }
    
    @IBAction func Cancel(sender: AnyObject)
    {
        
    }
    
    func GetPlayerPool()
    {
        let request = NSMutableURLRequest(URL: NSURL(string: "http://dcm.uhcl.edu/c432015sp03parankushams/WebService.asmx/PlayerPool")!)
        httpGet(request)
        {
            (data, error) -> Void in
                if error != nil
                {
                    print(error)
                }
                else
                {
                    self.extract_json(data)
                }
                
        }
        
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var coun = 0
        
        if section == 0
        {
            coun = Bowler.count
            
        }
        
        if section == 1
        {
            coun = Batsman.count
            
            
        }
        if section == 2
        {
            coun = AllROunder.count
            
        }
        if section == 3
        {
            coun = WicketKeepr.count
            
        }
        
        return coun
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 4
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var header = ["Bowler","Batsman","AllRounder","Wicket Keeper"]
        
        let Playerheader : UILabel = UILabel()
        
        Playerheader.textColor = UIColor.redColor()
        Playerheader.text = header[section]
        return Playerheader
        
        
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cell : UITableViewCell = tableView.dequeueReusableCellWithIdentifier("PlayerCell", forIndexPath: indexPath)
        
        
        let cell2 = tableView.cellForRowAtIndexPath(indexPath)
        
        //let cell : UITableViewCell = tableView.
        
        
            
        cell.textLabel?.textColor = UIColor.blueColor()
       if indexPath.section == 0
        
       {
        let sortedarray = totalarrayBowler.sort{ ($0[1] as! String) < ($1[1] as! String) }
    
        
        if keys.contains(totalarrayBowler[indexPath.row][1])
        {
            cell.textLabel?.textColor = UIColor.redColor()
           // cell.detailTextLabel?.textColor = UIColor.redColor()
            cell.textLabel?.text = totalarrayBowler[indexPath.row][1]
            cell.detailTextLabel?.text = "\(totalarrayBowler[indexPath.row][3]) Price : \(totalarrayBowler[indexPath.row][4])"
            
            indexdata.append(indexPath.row)
           
        }
        else
        {
            cell.textLabel?.text = totalarrayBowler[indexPath.row][1]
            cell.detailTextLabel?.text = "\(totalarrayBowler[indexPath.row][3]) Price : \(totalarrayBowler[indexPath.row][4])"

        }
        
        }
        
        if indexPath.section == 1
        {
            let sortedarray = totalarrayBatsman.sort{ ($0[1] as! String) < ($1[1] as! String) }
          /*
            let teamDictionary1 = Batsman.sort {$0.0 < $1.0}
            for (var i = 0; i < teamDictionary1.count; i++)
            {
                teamDictionary3["\(teamDictionary1[i].0)"] = "\(teamDictionary1[i].1)"
                
            }
            let key = [String](teamDictionary.keys)
            let value = [String](teamDictionary.values)
            
            for (index, entry) in teamDictionary1
            {
                
                cell.textLabel?.text = teamDictionary1[indexPath.row].0
                cell.detailTextLabel?.text = teamDictionary1[indexPath.row].1
                
            }
            */
            
            if keys.contains(totalarrayBatsman[indexPath.row][1])
            {
                cell.textLabel?.textColor = UIColor.redColor()
                // cell.detailTextLabel?.textColor = UIColor.redColor()
                cell.textLabel?.text = totalarrayBatsman[indexPath.row][1]
                cell.detailTextLabel?.text = "\(totalarrayBatsman[indexPath.row][3]) Price : \(totalarrayBatsman[indexPath.row][4])"
                indexdata.append(indexPath.row)
            }
            else
            {
            cell.textLabel?.text = totalarrayBatsman[indexPath.row][1]
            cell.detailTextLabel?.text = "\(totalarrayBatsman[indexPath.row][3]) Price : \(totalarrayBatsman[indexPath.row][4])"
            }
        }
       
        if indexPath.section == 2
        {
            let sortedarray = totalarrayAllRounder.sort{ ($0[1] as! String) < ($1[1] as! String) }
           
            /*
            let teamDictionary1 = AllROunder.sort {$0.0 < $1.0}
            for (var i = 0; i < teamDictionary1.count; i++)
            {
                teamDictionary3["\(teamDictionary1[i].0)"] = "\(teamDictionary1[i].1)"
                
            }
            let key = [String](teamDictionary.keys)
            let value = [String](teamDictionary.values)
            
            for (index, entry) in teamDictionary1
            {
                
                cell.textLabel?.text = teamDictionary1[indexPath.row].0
                cell.detailTextLabel?.text = teamDictionary1[indexPath.row].1
                
            }
            
            */
            
            if keys.contains(totalarrayAllRounder[indexPath.row][1])
            {
                cell.textLabel?.textColor = UIColor.redColor()
                // cell.detailTextLabel?.textColor = UIColor.redColor()
                cell.textLabel?.text = totalarrayAllRounder[indexPath.row][1]
                cell.detailTextLabel?.text = "\(totalarrayAllRounder[indexPath.row][3]) Price : \(totalarrayAllRounder[indexPath.row][4])"
                indexdata.append(indexPath.row)

            }
            else
            {
            cell.textLabel?.text = totalarrayAllRounder[indexPath.row][1]
            cell.detailTextLabel?.text = "\(totalarrayAllRounder[indexPath.row][3]) Price : \(totalarrayAllRounder[indexPath.row][4])"
            }
        }
        if indexPath.section == 3
        {
            
            let sortedarray = totalarrayWicketKeeper.sort{ ($0[1] as! String) < ($1[1] as! String) }
          /*
            let teamDictionary1 = WicketKeepr.sort {$0.0 < $1.0}
            for (var i = 0; i < teamDictionary1.count; i++)
            {
                teamDictionary3["\(teamDictionary1[i].0)"] = "\(teamDictionary1[i].1)"
                
            }
            let key = [String](teamDictionary.keys)
            let value = [String](teamDictionary.values)
            
            for (index, entry) in teamDictionary1
            {
                
                cell.textLabel?.text = teamDictionary1[indexPath.row].0
                cell.detailTextLabel?.text = teamDictionary1[indexPath.row].1
                
            }  */
            
            if keys.contains(totalarrayWicketKeeper[indexPath.row][1])
            {
                cell.textLabel?.textColor = UIColor.redColor()
                // cell.detailTextLabel?.textColor = UIColor.redColor()
                cell.textLabel?.text = totalarrayWicketKeeper[indexPath.row][1]
                cell.detailTextLabel?.text = "\(totalarrayWicketKeeper[indexPath.row][3]) Price : \(totalarrayWicketKeeper[indexPath.row][4])"
                indexdata.append(indexPath.row)

               
            }
            
            else
            {
            cell.textLabel?.text = totalarrayWicketKeeper[indexPath.row][1]
            cell.detailTextLabel?.text = "\(totalarrayWicketKeeper[indexPath.row][3]) Price : \(totalarrayWicketKeeper[indexPath.row][4])"
            }
        }
        
        
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let cell = tableView.cellForRowAtIndexPath(indexPath)
       
        for var i = 0; i < indexdata.count; i++
        {
          // let cell2 = tableView.cellForRowAtIndexPath(indexdata[i])
            
        }
        
        
        if cell!.selected
        {
            
            cell!.selected = false
            if cell!.accessoryType == UITableViewCellAccessoryType.None
            {
                if indexPath.section == 0
                {
                    if team.count < 11
                    {
                        if teambat.count < typearray[0]
                        {
                        cell!.accessoryType = UITableViewCellAccessoryType.Checkmark
                        var abc = cell!.textLabel!.text!
                        var abc2 = cell!.detailTextLabel!.text!
                        if team.contains(abc)
                        {
                    
                        }
                        else
                        {
                            if pri > 0
                            {
                            teambat.append(abc)
                            team.append(abc)
                            teamDictionary2["\(abc)"] = "\(abc2)"
                            playerDic2["\(abc)"] = playerDic["\(abc)"]
                            value = playerDic["\(abc)"]!
                            var str = abc2.componentsSeparatedByString(": ")
                             var str2 = str[1]
                            
                                pri = pri - Int(str2)!
                                if pri < 0
                                {
                                    displayAlertMessage("Please Check The amount")
                                }
                                else
                                {
                                price.text = "\(pri)"
                            
                                }
                            }
                        }
                            print(team)
                            print(playerDic2)
                            print(teamDictionary2)
                        }
                        else
                        {
                            displayAlertMessage("Please select team in choosen format")
                        }
                        
                        
                        print("teambat\(teambat)")
     
                    }
                }
                
                else if indexPath.section == 1
                {
                    if team.count < 11
                    {
                        if teambow.count < typearray[1]
                        {
                            cell!.accessoryType = UITableViewCellAccessoryType.Checkmark
                            var abc = cell!.textLabel!.text!
                            var abc2 = cell!.detailTextLabel!.text!
                            if team.contains(abc)
                            {
                                
                            }
                            else
                            {
                                if pri > 0
                                {
                                    teambow.append(abc)
                                    team.append(abc)
                                    teamDictionary2["\(abc)"] = "\(abc2)"
                                    playerDic2["\(abc)"] = playerDic["\(abc)"]
                                    value = playerDic["\(abc)"]!

                                    var str = abc2.componentsSeparatedByString(": ")
                                    var str2 = str[1]
                                
                                    pri = pri - Int(str2)!
                                    if pri < 0
                                    {
                                        displayAlertMessage("Please Check The amount")
                                    }
                                    else
                                    {
                                    
                                    price.text = "\(pri)"
                                    }
                                }
                                
                            }
                            print(team)
                            print(playerDic2)
                            print(teamDictionary2)
                        }
                        else
                        {
                            displayAlertMessage("Please select team in choosen format")
                        }
                        
                        
                        print("teambat\(teambat)")
                        
                    }

                }
                
                else if indexPath.section == 2
                {
                    if team.count < 11
                    {
                        if teamall.count < typearray[2]
                        {
                            cell!.accessoryType = UITableViewCellAccessoryType.Checkmark
                            var abc = cell!.textLabel!.text!
                            var abc2 = cell!.detailTextLabel!.text!
                            if team.contains(abc)
                            {
                                
                            }
                            else
                            {
                                if pri > 0
                                {
                                teamall.append(abc)
                                team.append(abc)
                                teamDictionary2["\(abc)"] = "\(abc2)"
                                playerDic2["\(abc)"] = playerDic["\(abc)"]
                                    value = playerDic["\(abc)"]!

                                var str = abc2.componentsSeparatedByString(": ")
                                var str2 = str[1]
                                
                                pri = pri - Int(str2)!
                                
                                    if pri < 0
                                    {
                                        displayAlertMessage("Please Check The amount")
                                    }
                                    
                                  else
                                    {
                                        price.text = "\(pri)"
                                    }
                                }
                                
                            }
                            print(team)
                            print(playerDic2)
                            print(teamDictionary2)
                        }
                        else
                        {
                            displayAlertMessage("Please select team in choosen format")
                        }
                        
                        
                        print("teambat\(teambat)")
                        
                    }
                    
                }
                
                else if indexPath.section == 3
                {
                    if team.count < 11
                    {
                        if teamwik.count < typearray[3]
                        {
                            cell!.accessoryType = UITableViewCellAccessoryType.Checkmark
                            var abc = cell!.textLabel!.text!
                            var abc2 = cell!.detailTextLabel!.text!
                            if team.contains(abc)
                            {
                                
                            }
                            else
                            {
                                if pri > 0
                                {
                                    teamwik.append(abc)
                                    team.append(abc)
                                    teamDictionary2["\(abc)"] = "\(abc2)"
                                    playerDic2["\(abc)"] = playerDic["\(abc)"]
                                    value = playerDic["\(abc)"]!

                                    var str = abc2.componentsSeparatedByString(": ")
                                    var str2 = str[1]
                                
                                    pri = pri - Int(str2)!
                                    if pri < 0
                                    {
                                        displayAlertMessage("Please Check The amount")
                                    }
                                    else
                                    {
                                    price.text = "\(pri)"
                                    }
                                }
                            }
                            print(team)
                            print(playerDic2)
                            print(teamDictionary2)
                        }
                        else
                        {
                            displayAlertMessage("Please select team in choosen format")
                        }
                        
                        
                        print("teambat\(teambat)")
                        
                    }
                    
                }
                    
                else
                {
                    displayAlertMessage("Hello You can only select 11 players")
                }
                
            }
         
            else
            {
                if team.count > 0 
                {
                    cell!.accessoryType = UITableViewCellAccessoryType.None
                    var abc2 = cell!.textLabel!.text!
                    var abc3 = cell!.detailTextLabel!.text!
                    var str = abc3.componentsSeparatedByString(": ")
                    var str2 = str[1]
                    
                    pri = pri + Int(str2)!
                    
                    price.text = "\(pri)"
                    
                    
                    
                    team = team.filter {$0 != "\(abc2)"}
                    teamDictionary2.removeValueForKey("\(abc2)")
                    playerDic2.removeValueForKey("\(abc2)")
                    //teamDictionary2 = teamDictionary2.filter {$0.0 != "\(abc2)"}
                    teamall = teamall.filter {$0 != "\(abc2)"}
                    teambat = teambat.filter {$0 != "\(abc2)"}
                    teambow = teambow.filter {$0 != "\(abc2)"}
                    teamwik = teamwik.filter {$0 != "\(abc2)"}
                    print(teamDictionary2)
                    print("Hello")
                }
                else
                {
                    displayAlertMessage("You can only select 11 players")
                }
                
            }
        
            
        }
    }
    
    
    func extract_json(data:String)
    {
        
        var parseError: NSError?
        let jsonData:NSData = data.dataUsingEncoding(NSASCIIStringEncoding)!
        do{
            let json: AnyObject = try NSJSONSerialization.JSONObjectWithData(jsonData, options: NSJSONReadingOptions.MutableContainers)
            
            //  print(json)
            if (parseError == nil)
            {
                if let countries_list = json as? NSArray
                {
                    //  print("hello   \(countries_list)")
                    for (var i = 0; i < countries_list.count ; i++ )
                    {
                        if let country_obj = countries_list[i] as? NSDictionary
                        {
                            //                        print("hello   \(country_obj)")
                            
                            
                            if let country_name = country_obj["PLAYER_NAME"] as? String
                            {
                                
                                // print("hello   \(country_name)")
                                
                                if let country_code = country_obj["PLAYER_TYPE"] as? String
                                {
                                    let player_id = country_obj["Player_id"] as? Int
                                    let playeridstring = "\(player_id!)"
                                   // var playeridstring = country_obj["Player_id"] as? String
                                    playid.append(player_id!)
                                    
                                    let teamname = country_obj["TEAM_NAME"] as? String
                                    let price = country_obj["RATE"] as? Int
                                    var pricestring = "\(price!)"
                                    
                                    singlearray.append(playeridstring)
                                    singlearray.append(country_name)
                                    singlearray.append(country_code)
                                    singlearray.append(teamname!)
                                    singlearray.append(pricestring)
                                    totalarray.append(singlearray)
                                    if singlearray.contains(playername)
                                    {
                                        value2 = playeridstring
                                    }
                                    
                                    
                                   // singlearray = []
                                    
                                    
                                   // print(" Hello TEAm \(playid)")
                                    
                                    if country_code == "Bowler"
                                    {
                                        totalarrayBowler.append(singlearray)
                                        singlearray = []
                                        
                                        Bowler["\(country_name)"] = "\(country_code)"
                                        
                                        TableData.append(country_name + " [" + country_code + "]")
                                        teamDictionary["\(country_name)"] = "\(country_code)"
                                        playerDic["\(country_name)"] = "\(player_id!)"
                                        
                                    }
                                    if country_code == "Batsman"
                                    {
                                        totalarrayBatsman.append(singlearray)
                                        singlearray = []
                                        
                                        Batsman["\(country_name)"] = "\(country_code)"
                                        
                                        TableData.append(country_name + " [" + country_code + "]")
                                        teamDictionary["\(country_name)"] = "\(country_code)"
                                        playerDic["\(country_name)"] = "\(player_id!)"
                                        
                                        
                                    }
                                    if country_code == "AllRounder"
                                    {
                                        totalarrayAllRounder.append(singlearray)
                                        singlearray = []
                                        
                                        AllROunder["\(country_name)"] = "\(country_code)"
                                        TableData.append(country_name + " [" + country_code + "]")
                                        teamDictionary["\(country_name)"] = "\(country_code)"
                                        playerDic["\(country_name)"] = "\(player_id!)"
                                    }
                                    
                                    if country_code == "Wicket Keeper"
                                    {
                                        totalarrayWicketKeeper.append(singlearray)
                                        singlearray = []
                                        
                                        WicketKeepr["\(country_name)"] = "\(country_code)"
                                        
                                        TableData.append(country_name + " [" + country_code + "]")
                                        teamDictionary["\(country_name)"] = "\(country_code)"
                                        playerDic["\(country_name)"] = "\(player_id!)"
                                    }
                                   
                                }
                            }
                        }
                    }
                   // print(TableData)
                   // print(teamDictionary)
                }
            }
            
            //  print(TableData)
            do_table_refresh();
            
        }
        catch{
            // print("error")
        }
        
        print(totalarray)
    }

    func do_table_refresh()
    {
        dispatch_async(dispatch_get_main_queue(), {
            self.tableView.reloadData()
            return
        })
    }

    func httpGet(request: NSURLRequest!, callback: (String, String?) -> Void)
    {
        var result = ""
        
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(request){
            (data, response, error) -> Void in
            if error != nil {
                callback("", error!.localizedDescription)
            } else {
                result = NSString(data: data!, encoding:
                    NSASCIIStringEncoding)! as String
                callback(result as String, nil)
              //  self.abc = result
            }
        }
        task.resume()
        
    }
    func displayAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Alert", message:userMessage, preferredStyle: UIAlertControllerStyle.Alert);
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler:nil)
        
        myAlert.addAction(okAction);
        
        self.presentViewController(myAlert, animated: true, completion: nil)
        
    }
    

}
